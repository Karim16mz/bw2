
/*Prototipi di funzione*/

void errorProne();
void correct();
int getMenuChoice();
